These files are for the Fitzwilliam Museum records

fwm_bib.mrc = bibligraphics records
fwm_mfhd.mrc = holdings records
fwm_bib_mfhd.mrc = bibliographic & holdings records in groups

Please note that in a Voyager holdings record the 852 subfield b has the location, whereas in an Alma holdings record the 852 subfield b has the library, and subfield c has the location. There may be other differences between the systems.